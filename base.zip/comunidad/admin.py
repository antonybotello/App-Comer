from django.contrib import admin
from comunidad.models import Usuario, Tienda
# Register your models here.
admin.site.register(Usuario)
admin.site.register(Tienda)


